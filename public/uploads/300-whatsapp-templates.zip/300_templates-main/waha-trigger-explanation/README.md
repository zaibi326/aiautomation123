[<- Back](/)

# WAHA Trigger Explanation
[**template.json**](./template.json)

![](workflow.png)

Explanation what is hidden behind the **WAHA Trigger** node.
