# Data_Analytics Templates

- **competitor_price_scraper.json** – Uses Anthropic Claude, OpenAI Embeddings, Supabase Vector