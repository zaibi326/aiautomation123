# Government_NGO Templates

- **public_form_auto_triage.json** – Uses Anthropic Claude, Cohere Embeddings, Supabase Vector
- **public_record_email_update.json** – Uses Cohere Embeddings, OpenAI Chat, Pinecone